package app.xlook;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * Runs inside the Shizuku "user service" process, which has shell (ADB) privileges.
 * It does one thing: run a shell command and return its exit code and output.
 *
 * It is a plain Binder, so no AIDL is needed. Shizuku asks for the class by name.
 *
 * If you change this file, raise VERSION so Shizuku restarts the service.
 */
public class ShellService extends Binder {
    static final String DESCRIPTOR = "app.xlook.ShellService";
    static final int TX_EXEC = IBinder.FIRST_CALL_TRANSACTION;
    /** Shizuku sends this code to ask the service to quit. */
    static final int TX_DESTROY = 16777115;
    static final int VERSION = 1;

    private static final int MAX_CHARS = 200_000;
    private static final long TIMEOUT_SECONDS = 25;

    public ShellService() {
        attachInterface(null, DESCRIPTOR);
    }

    @Override
    protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        if (code == TX_DESTROY) {
            System.exit(0);
            return true;
        }
        if (code == TX_EXEC) {
            data.enforceInterface(DESCRIPTOR);
            String command = data.readString();
            int[] exit = new int[1];
            String output = exec(command, exit);
            if (reply != null) {
                reply.writeNoException();
                reply.writeInt(exit[0]);
                reply.writeString(output);
            }
            return true;
        }
        return super.onTransact(code, data, reply, flags);
    }

    private static String exec(String command, int[] exitOut) {
        StringBuilder sb = new StringBuilder();
        try {
            ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", command);
            pb.redirectErrorStream(true);
            final Process p = pb.start();
            p.getOutputStream().close();

            Thread watchdog = new Thread(() -> {
                try {
                    if (!p.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                        p.destroyForcibly();
                    }
                } catch (InterruptedException ignored) {
                    // finished early
                }
            });
            watchdog.setDaemon(true);
            watchdog.start();

            try (Reader r = new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8)) {
                char[] buf = new char[4096];
                int n;
                while ((n = r.read(buf)) > 0) {
                    if (sb.length() < MAX_CHARS) sb.append(buf, 0, n);
                }
            }
            exitOut[0] = p.waitFor();
            watchdog.interrupt();
        } catch (IOException | InterruptedException e) {
            exitOut[0] = -1;
            sb.append(e);
        }
        return sb.toString();
    }
}
