package app.xlook;

import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

/** Display size, text size, dark mode and refresh rate. */
final class DisplayPage extends Page {
    private static final int STEP = 5;
    private static final float FONT_MIN = 0.85f;
    private static final float FONT_STEP = 0.05f;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int physical = -1;
    private int override = -1; // active density override, -1 when there is none
    private int densityMin;

    DisplayPage(MainActivity a) {
        super(a);
    }

    @Override
    String title() {
        return "Display";
    }

    @Override
    View build() {
        Ui ui = ui();
        LinearLayout root = ui.vbox();
        root.addView(sizeCard(ui));
        root.addView(textCard(ui));
        root.addView(themeCard(ui));
        return ui.scroll(root);
    }

    @Override
    void onLeave() {
        handler.removeCallbacksAndMessages(null);
    }

    private int densityAt(int progress) {
        return densityMin + progress * STEP;
    }

    private View sizeCard(Ui ui) {
        LinearLayout c = ui.card();
        c.addView(ui.body("Display size"));
        c.addView(ui.hint("Lower numbers make everything smaller, so more fits on screen."));

        TextView value = ui.label("Reading…", 15, ui.accent, true);
        value.setPadding(0, ui.dp(10), 0, ui.dp(4));
        c.addView(value);

        SeekBar seek = new SeekBar(a);
        seek.setEnabled(false);
        c.addView(seek, Ui.lp(Ui.MATCH, Ui.WRAP));

        LinearLayout buttons = ui.hbox();
        TextView apply = ui.button("Apply", true, v -> {
            final int wanted = densityAt(seek.getProgress());
            final int previous = override;
            sh().run("wm density " + wanted, r -> {
                if (r.ok()) {
                    override = wanted;
                    askKeep(previous);
                } else {
                    a.toast("Failed: " + r.firstLine());
                }
            });
        });
        TextView reset = ui.button("Reset", false, v ->
                sh().run("wm density reset", r -> {
                    if (r.ok()) {
                        override = -1;
                        a.rebuild();
                    } else {
                        a.toast("Failed: " + r.firstLine());
                    }
                }));
        buttons.addView(apply, Ui.weight(1));
        LinearLayout.LayoutParams rp = Ui.weight(1);
        rp.leftMargin = ui.dp(10);
        buttons.addView(reset, rp);
        LinearLayout.LayoutParams bp = Ui.lp(Ui.MATCH, Ui.WRAP);
        bp.topMargin = ui.dp(8);
        c.addView(buttons, bp);

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (physical <= 0) return;
                int d = densityAt(progress);
                value.setText(String.format(Locale.US, "%d dpi  ·  %d%% of normal", d, Math.round(d * 100f / physical)));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {}

            @Override
            public void onStopTrackingTouch(SeekBar s) {}
        });

        sh().run("wm density", r -> {
            int[] d = Parse.density(r.out);
            if (d[0] <= 0) {
                value.setText("Could not read the display size");
                return;
            }
            physical = d[0];
            override = d[1];
            int current = override > 0 ? override : physical;
            densityMin = Math.round(physical * 0.70f / STEP) * STEP;
            int densityMax = Math.round(physical * 1.15f / STEP) * STEP;
            seek.setMax((densityMax - densityMin) / STEP);
            int p = Math.round((current - densityMin) / (float) STEP);
            seek.setProgress(Math.max(0, Math.min(seek.getMax(), p)));
            seek.setEnabled(true);
            // setProgress does not call the listener when the value is unchanged, so set the text here too.
            value.setText(String.format(Locale.US, "%d dpi  ·  %d%% of normal", current, Math.round(current * 100f / physical)));
        });
        return c;
    }

    /** After a size change, give the user 10 seconds to confirm. If they do nothing, go back. */
    private void askKeep(final int previousOverride) {
        final int[] left = {10};
        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle("Keep this display size?")
                .setMessage(keepMessage(left[0]))
                .setCancelable(false)
                .setPositiveButton("Keep", (d, w) -> handler.removeCallbacksAndMessages(null))
                .setNegativeButton("Revert", (d, w) -> {
                    handler.removeCallbacksAndMessages(null);
                    revert(previousOverride);
                })
                .create();
        dialog.show();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!dialog.isShowing()) return;
                left[0]--;
                if (left[0] <= 0) {
                    dialog.dismiss();
                    revert(previousOverride);
                } else {
                    dialog.setMessage(keepMessage(left[0]));
                    handler.postDelayed(this, 1000);
                }
            }
        }, 1000);
    }

    private static String keepMessage(int seconds) {
        return "Going back to the old size in " + seconds + " s unless you tap Keep.";
    }

    private void revert(int previousOverride) {
        String cmd = previousOverride > 0 ? "wm density " + previousOverride : "wm density reset";
        sh().run(cmd, r -> {
            override = previousOverride;
            a.rebuild();
        });
    }

    private View textCard(Ui ui) {
        LinearLayout c = ui.card();
        c.addView(ui.body("Text size"));
        c.addView(ui.hint("Changes the system font scale."));

        TextView value = ui.label("Reading…", 15, ui.accent, true);
        value.setPadding(0, ui.dp(10), 0, ui.dp(4));
        c.addView(value);

        SeekBar seek = new SeekBar(a);
        seek.setMax(9);
        seek.setEnabled(false);
        c.addView(seek, Ui.lp(Ui.MATCH, Ui.WRAP));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                value.setText(String.format(Locale.US, "%.2f×", FONT_MIN + progress * FONT_STEP));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {}

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                float scale = FONT_MIN + s.getProgress() * FONT_STEP;
                sh().run(String.format(Locale.US, "settings put system font_scale %.2f", scale), r -> {
                    if (!r.ok()) a.toast("Failed: " + r.firstLine());
                });
            }
        });

        sh().getSettings(new String[][] {{"system", "font_scale"}}, values -> {
            float current = Parse.toFloat(values[0], 1.0f);
            int p = Math.round((current - FONT_MIN) / FONT_STEP);
            seek.setProgress(Math.max(0, Math.min(9, p)));
            seek.setEnabled(true);
            value.setText(String.format(Locale.US, "%.2f×", FONT_MIN + seek.getProgress() * FONT_STEP));
        });
        return c;
    }

    private View themeCard(Ui ui) {
        LinearLayout c = ui.card();

        c.addView(ui.body("Dark mode"));
        Ui.Segmented dark = ui.segmented(new String[] {"Auto", "Light", "Dark"}, i -> {
            String mode = i == 0 ? "auto" : i == 1 ? "no" : "yes";
            sh().run("cmd uimode night " + mode, r -> {
                if (!r.ok()) a.toast("Failed: " + r.firstLine());
            });
        });
        LinearLayout.LayoutParams dp = Ui.lp(Ui.MATCH, Ui.WRAP);
        dp.topMargin = ui.dp(8);
        c.addView(dark, dp);
        sh().run("cmd uimode night", r -> {
            String m = Parse.nightMode(r.out);
            if ("auto".equals(m)) dark.select(0);
            else if ("no".equals(m)) dark.select(1);
            else if ("yes".equals(m)) dark.select(2);
        });

        c.addView(ui.gap(16));
        c.addView(ui.body("Refresh rate"));
        c.addView(ui.hint("Asks the display to stay at a fixed rate. Some Infinix software versions ignore this."));
        final int[] rates = {0, 60, 90, 120};
        Ui.Segmented rate = ui.segmented(new String[] {"Auto", "60 Hz", "90 Hz", "120 Hz"}, i -> {
            String cmd;
            if (rates[i] == 0) {
                cmd = "settings delete system min_refresh_rate\nsettings delete system peak_refresh_rate";
            } else {
                String hz = rates[i] + ".0";
                cmd = "settings put system min_refresh_rate " + hz + "\nsettings put system peak_refresh_rate " + hz;
            }
            sh().run(cmd, r -> {
                if (!r.ok()) a.toast("Failed: " + r.firstLine());
            });
        });
        LinearLayout.LayoutParams rp = Ui.lp(Ui.MATCH, Ui.WRAP);
        rp.topMargin = ui.dp(8);
        c.addView(rate, rp);
        sh().getSettings(new String[][] {{"system", "min_refresh_rate"}, {"system", "peak_refresh_rate"}}, values -> {
            if (values[1] == null) {
                rate.select(0);
                return;
            }
            int hz = Math.round(Parse.toFloat(values[1], 0f));
            for (int i = 1; i < rates.length; i++) {
                if (rates[i] == hz) rate.select(i);
            }
        });
        return c;
    }
}
