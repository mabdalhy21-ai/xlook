package app.xlook;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.provider.Telephony;
import android.telecom.TelecomManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Lists every app and lets you disable, remove (for this user) or restore it. Think Canta, built in. */
final class AppsPage extends Page {

    static final class Item {
        final String pkg;
        final String label;
        final boolean system;
        final boolean enabled;
        final boolean installed;

        Item(String pkg, String label, boolean system, boolean enabled, boolean installed) {
            this.pkg = pkg;
            this.label = label;
            this.system = system;
            this.enabled = enabled;
            this.installed = installed;
        }
    }

    /** Apps the phone cannot run without. XLook will not touch these. "android" must match exactly, the rest by prefix. */
    private static final String[] PROTECTED_PREFIXES = {
            "com.android.systemui", "com.android.settings", "com.android.phone", "com.android.providers.",
            "com.android.server.", "com.android.inputmethod", "com.android.shell", "com.android.packageinstaller",
            "com.google.android.packageinstaller", "com.android.permissioncontroller",
            "com.google.android.permissioncontroller", "com.android.bluetooth", "com.android.nfc",
            "com.android.networkstack", "com.google.android.networkstack", "com.android.cellbroadcast",
            "com.android.location", "com.android.keychain", "com.android.certinstaller", "com.android.webview",
            "com.google.android.webview", "com.google.android.gms", "com.google.android.gsf",
            "com.android.vending", "com.mediatek.", "com.android.wifi", "com.android.carrierconfig",
            "moe.shizuku.privileged.api",
    };

    private final List<Item> all = new ArrayList<>();
    private final List<Item> shown = new ArrayList<>();
    private final Set<String> protectedNow = new HashSet<>();
    private final Set<String> iconLoading = new HashSet<>();
    private final LruCache<String, Drawable> icons = new LruCache<>(120);
    private final Handler main = new Handler(Looper.getMainLooper());

    private BaseAdapter adapter;
    private TextView count;
    private int filter = 0; // 0 user, 1 system, 2 disabled, 3 removed
    private String query = "";

    AppsPage(MainActivity a) {
        super(a);
    }

    @Override
    String title() {
        return "Apps";
    }

    @Override
    View build() {
        Ui ui = ui();
        LinearLayout root = ui.vbox();
        root.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), 0);

        EditText search = ui.input("Search apps");
        search.setText(query);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int c, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                query = s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }
        });
        root.addView(search, Ui.lp(Ui.MATCH, Ui.WRAP));

        Ui.Segmented seg = ui.segmented(new String[] {"User", "System", "Disabled", "Removed"}, i -> {
            filter = i;
            applyFilter();
        });
        seg.select(filter);
        LinearLayout.LayoutParams sp = Ui.lp(Ui.MATCH, Ui.WRAP);
        sp.topMargin = ui.dp(10);
        root.addView(seg, sp);

        count = ui.hint("Loading apps…");
        count.setPadding(ui.dp(4), ui.dp(10), 0, ui.dp(6));
        root.addView(count);

        ListView list = new ListView(a);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(android.R.color.transparent);
        list.setClipToPadding(false);
        list.setPadding(0, 0, 0, ui.dp(16));
        adapter = new AppAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, v, position, id) -> {
            if (position >= 0 && position < shown.size()) showActions(shown.get(position));
        });
        root.addView(list, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));

        load();
        return root;
    }

    // ---- data ------------------------------------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    private void load() {
        a.bg.execute(() -> {
            PackageManager pm = a.getPackageManager();
            int flags = PackageManager.MATCH_UNINSTALLED_PACKAGES
                    | PackageManager.MATCH_DISABLED_COMPONENTS
                    | PackageManager.MATCH_DISABLED_UNTIL_USED_COMPONENTS;
            List<ApplicationInfo> infos = pm.getInstalledApplications(flags);
            List<Item> items = new ArrayList<>();
            for (ApplicationInfo ai : infos) {
                String label;
                try {
                    label = String.valueOf(ai.loadLabel(pm));
                } catch (RuntimeException e) {
                    label = ai.packageName;
                }
                boolean system = (ai.flags & (ApplicationInfo.FLAG_SYSTEM | ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0;
                boolean installed = (ai.flags & ApplicationInfo.FLAG_INSTALLED) != 0;
                items.add(new Item(ai.packageName, label, system, ai.enabled, installed));
            }
            Collections.sort(items, (x, y) -> x.label.compareToIgnoreCase(y.label));
            Set<String> prot = dynamicProtected(a);
            main.post(() -> {
                all.clear();
                all.addAll(items);
                protectedNow.clear();
                protectedNow.addAll(prot);
                applyFilter();
            });
        });
    }

    private void applyFilter() {
        shown.clear();
        for (Item it : all) {
            boolean match;
            switch (filter) {
                case 0:
                    match = it.installed && !it.system && it.enabled;
                    break;
                case 1:
                    match = it.installed && it.system && it.enabled;
                    break;
                case 2:
                    match = it.installed && !it.enabled;
                    break;
                default:
                    match = !it.installed;
                    break;
            }
            if (!match) continue;
            if (!query.isEmpty()
                    && !it.label.toLowerCase(Locale.ROOT).contains(query)
                    && !it.pkg.toLowerCase(Locale.ROOT).contains(query)) {
                continue;
            }
            shown.add(it);
        }
        if (count != null) count.setText(shown.size() + (shown.size() == 1 ? " app" : " apps"));
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    /** Default launcher, dialer, SMS app and keyboard, plus this app. Looked up on a background thread. */
    private static Set<String> dynamicProtected(Context c) {
        Set<String> s = new HashSet<>();
        s.add(c.getPackageName());
        try {
            PackageManager pm = c.getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo ri = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri != null && ri.activityInfo != null) s.add(ri.activityInfo.packageName);
            TelecomManager tm = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
            if (tm != null) {
                String dialer = tm.getDefaultDialerPackage();
                if (dialer != null) s.add(dialer);
            }
            String sms = Telephony.Sms.getDefaultSmsPackage(c);
            if (sms != null) s.add(sms);
            String ime = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
            if (ime != null && ime.contains("/")) s.add(ime.substring(0, ime.indexOf('/')));
        } catch (RuntimeException ignored) {
            // keep whatever we found
        }
        return s;
    }

    private boolean isProtected(String pkg) {
        if (pkg.equals("android") || protectedNow.contains(pkg)) return true;
        for (String p : PROTECTED_PREFIXES) {
            if (pkg.startsWith(p)) return true;
        }
        return false;
    }

    // ---- actions ---------------------------------------------------------------------------------------------

    private void showActions(Item it) {
        final List<CharSequence> names = new ArrayList<>();
        final List<Runnable> acts = new ArrayList<>();
        boolean prot = isProtected(it.pkg);

        if (!prot) {
            if (!it.installed) {
                names.add("Restore");
                acts.add(() -> change(it, "cmd package install-existing --user 0 " + it.pkg, "Restored " + it.label));
            } else {
                if (it.enabled) {
                    names.add("Disable");
                    acts.add(() -> a.confirm("Disable " + it.label + "?",
                            "The app stops running and disappears from the launcher. You can enable it again here. "
                                    + "Disabling system apps can break features.",
                            () -> change(it, "pm disable-user --user 0 " + it.pkg, "Disabled " + it.label)));
                } else {
                    names.add("Enable");
                    acts.add(() -> change(it, "pm enable --user 0 " + it.pkg, "Enabled " + it.label));
                }
                names.add("Remove for this user");
                acts.add(() -> a.confirm("Remove " + it.label + "?",
                        "The app is taken off this phone for your user, but its files stay. You can bring it back "
                                + "from the Removed tab. Removing system apps can break features.",
                        () -> change(it, "pm uninstall -k --user 0 " + it.pkg, "Removed " + it.label)));
            }
        }
        if (it.installed) {
            names.add("Open app info");
            acts.add(() -> openInfo(it));
        }
        if (names.isEmpty()) {
            a.toast("Nothing to do for this app");
            return;
        }
        new AlertDialog.Builder(a)
                .setTitle(prot ? it.label + " (protected)" : it.label)
                .setItems(names.toArray(new CharSequence[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    private void change(Item it, String command, String doneText) {
        if (!Parse.safePackage(it.pkg)) {
            a.toast("Odd package name, skipped");
            return;
        }
        sh().run(command, r -> {
            if (r.ok()) {
                a.toast(doneText);
                load();
            } else {
                a.toast("Failed: " + r.firstLine());
            }
        });
    }

    private void openInfo(Item it) {
        try {
            a.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + it.pkg)));
        } catch (RuntimeException e) {
            a.toast("Could not open app info");
        }
    }

    // ---- list rows -------------------------------------------------------------------------------------------

    private static final class Holder {
        ImageView icon;
        TextView label;
        TextView pkg;
        TextView state;
    }

    private final class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Item getItem(int position) {
            return shown.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Ui ui = ui();
            Holder h;
            View view = convertView;
            if (view == null) {
                FrameLayout wrap = new FrameLayout(a);
                wrap.setPadding(0, 0, 0, ui.dp(8));

                LinearLayout row = ui.hbox();
                row.setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10));
                row.setBackground(ui.ripple(ui.card, 16));

                h = new Holder();
                h.icon = new ImageView(a);
                row.addView(h.icon, Ui.lp(ui.dp(40), ui.dp(40)));

                LinearLayout text = ui.vbox();
                h.label = ui.label("", 16, ui.text, true);
                h.label.setSingleLine(true);
                h.pkg = ui.hint("");
                h.pkg.setSingleLine(true);
                text.addView(h.label);
                text.addView(h.pkg);
                LinearLayout.LayoutParams tp = Ui.weight(1);
                tp.leftMargin = ui.dp(12);
                row.addView(text, tp);

                h.state = ui.label("", 12, ui.sub, true);
                h.state.setGravity(Gravity.END);
                LinearLayout.LayoutParams sp = Ui.lp(Ui.WRAP, Ui.WRAP);
                sp.leftMargin = ui.dp(8);
                row.addView(h.state, sp);

                wrap.addView(row, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
                wrap.setTag(h);
                view = wrap;
            } else {
                h = (Holder) view.getTag();
            }

            final Item it = shown.get(position);
            h.label.setText(it.label);
            h.pkg.setText(it.pkg);
            if (!it.installed) {
                h.state.setText("Removed");
                h.state.setTextColor(ui.danger);
            } else if (!it.enabled) {
                h.state.setText("Disabled");
                h.state.setTextColor(ui.danger);
            } else if (isProtected(it.pkg)) {
                h.state.setText("Protected");
                h.state.setTextColor(ui.sub);
            } else {
                h.state.setText("");
            }

            h.icon.setTag(it.pkg);
            Drawable cached = icons.get(it.pkg);
            if (cached != null) {
                h.icon.setImageDrawable(cached);
            } else {
                h.icon.setImageDrawable(null);
                loadIcon(it.pkg, h.icon);
            }
            return view;
        }
    }

    private void loadIcon(final String pkg, final ImageView target) {
        if (!iconLoading.add(pkg)) return;
        a.bg.execute(() -> {
            PackageManager pm = a.getPackageManager();
            Drawable d;
            try {
                d = pm.getApplicationIcon(pkg);
            } catch (PackageManager.NameNotFoundException | RuntimeException e) {
                d = pm.getDefaultActivityIcon();
            }
            final Drawable result = d;
            main.post(() -> {
                iconLoading.remove(pkg);
                icons.put(pkg, result);
                if (pkg.equals(target.getTag())) target.setImageDrawable(result);
                if (adapter != null) adapter.notifyDataSetChanged();
            });
        });
    }
}
