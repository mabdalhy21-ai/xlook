package app.xlook;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

/** Hosts the pages and looks after the Shizuku connection. */
public class MainActivity extends Activity {

    enum State { NOT_INSTALLED, NOT_RUNNING, TOO_OLD, NEEDS_PERMISSION, CONNECTING, READY }

    static final String SHIZUKU_PACKAGE = "moe.shizuku.privileged.api";
    private static final int REQUEST_SHIZUKU = 4711;

    Ui ui;
    final Shell shell = new Shell();
    final ExecutorService bg = Executors.newFixedThreadPool(3);

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ArrayList<Page> stack = new ArrayList<>();

    private LinearLayout topBar;
    private TextView topTitle;
    private FrameLayout container;

    private Shizuku.UserServiceArgs serviceArgs;
    private boolean binding;

    private final Shizuku.OnBinderReceivedListener binderReceived = () -> {
        tryBind();
        notifyState();
    };
    private final Shizuku.OnBinderDeadListener binderDead = () -> {
        shell.setBinder(null);
        binding = false;
        notifyState();
    };
    private final Shizuku.OnRequestPermissionResultListener permissionResult = (requestCode, grantResult) -> {
        tryBind();
        notifyState();
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            binding = false;
            shell.setBinder(service);
            notifyState();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            binding = false;
            shell.setBinder(null);
            notifyState();
        }
    };

    // ---- lifecycle -------------------------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        serviceArgs = new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), ShellService.class.getName()))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(false)
                .version(ShellService.VERSION)
                .tag("xlook-shell");

        buildChrome();
        stack.add(new HomePage(this));
        render();

        Shizuku.addBinderReceivedListenerSticky(binderReceived, main);
        Shizuku.addBinderDeadListener(binderDead, main);
        Shizuku.addRequestPermissionResultListener(permissionResult, main);
    }

    @Override
    protected void onResume() {
        super.onResume();
        tryBind();
        notifyState();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived);
        Shizuku.removeBinderDeadListener(binderDead);
        Shizuku.removeRequestPermissionResultListener(permissionResult);
        if (isFinishing()) {
            try {
                Shizuku.unbindUserService(serviceArgs, connection, true);
            } catch (Throwable ignored) {
                // Shizuku may already be gone
            }
            bg.shutdown();
        }
        super.onDestroy();
    }

    /** Dark mode, text size or screen density changed: rebuild everything with the new values. */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        buildChrome();
        render();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (stack.size() > 1) {
            stack.remove(stack.size() - 1).onLeave();
            render();
        } else {
            super.onBackPressed();
        }
    }

    // ---- screen ----------------------------------------------------------------------------------------------

    private void buildChrome() {
        ui = new Ui(this);

        LinearLayout root = ui.vbox();
        root.setBackgroundColor(ui.bg);

        topBar = ui.hbox();
        topBar.setPadding(ui.dp(8), ui.dp(8), ui.dp(16), ui.dp(4));
        TextView back = ui.label("←", 24, ui.text, true);
        back.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6));
        back.setClickable(true);
        back.setBackground(ui.ripple(0x00000000, 24));
        back.setOnClickListener(v -> onBackPressed());
        topTitle = ui.label("", 20, ui.text, true);
        topBar.addView(back);
        topBar.addView(topTitle);

        container = new FrameLayout(this);
        root.addView(topBar, Ui.lp(Ui.MATCH, Ui.WRAP));
        root.addView(container, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));
        setContentView(root);

        getWindow().setStatusBarColor(ui.bg);
        getWindow().setNavigationBarColor(ui.bg);
        WindowInsetsController c = getWindow().getInsetsController();
        if (c != null) {
            int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                    | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            c.setSystemBarsAppearance(ui.dark ? 0 : mask, mask);
        }
    }

    private Page top() {
        return stack.get(stack.size() - 1);
    }

    /** Draws the page on top of the stack again. */
    void rebuild() {
        render();
    }

    private void render() {
        Page p = top();
        container.removeAllViews();
        container.addView(p.build(), new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        topBar.setVisibility(stack.size() > 1 ? View.VISIBLE : View.GONE);
        topTitle.setText(p.title());
    }

    void push(Page p) {
        top().onLeave();
        stack.add(p);
        render();
    }

    // ---- small helpers used by pages -------------------------------------------------------------------------

    void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    void confirm(String title, String message, Runnable onYes) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Yes", (d, w) -> onYes.run())
                .setNegativeButton("Cancel", null)
                .show();
    }

    void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (RuntimeException e) {
            toast("No browser found");
        }
    }

    void openShizuku() {
        Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PACKAGE);
        if (i == null) {
            toast("Shizuku is not installed");
        } else {
            startActivity(i);
        }
    }

    void resetAll() {
        shell.runAll(new String[] {
                "settings put system font_scale 1.0",
                "cmd uimode night auto",
                "settings delete system min_refresh_rate",
                "settings delete system peak_refresh_rate",
                "settings delete secure icon_blacklist",
                "settings delete system status_bar_show_battery_percent",
                "settings delete secure clock_seconds",
                "settings put global window_animation_scale 1.0",
                "settings put global transition_animation_scale 1.0",
                "settings put global animator_duration_scale 1.0",
                "settings put system show_touches 0",
                "settings put system pointer_location 0",
                "settings put global stay_on_while_plugged_in 0",
                "settings put global always_finish_activities 0",
                "wm density reset",
        }, r -> {
            toast(r.ok() ? "Everything is back to normal" : "Some resets failed: " + r.firstLine());
            render();
        });
    }

    // ---- Shizuku ---------------------------------------------------------------------------------------------

    private boolean isShizukuInstalled() {
        try {
            getPackageManager().getPackageInfo(SHIZUKU_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    State shizukuState() {
        try {
            if (!Shizuku.pingBinder()) {
                return isShizukuInstalled() ? State.NOT_RUNNING : State.NOT_INSTALLED;
            }
            if (Shizuku.isPreV11()) return State.TOO_OLD;
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return State.NEEDS_PERMISSION;
        } catch (Throwable t) {
            return State.NOT_RUNNING;
        }
        return shell.ready() ? State.READY : State.CONNECTING;
    }

    String shizukuPrivilege() {
        try {
            return Shizuku.getUid() == 0 ? "root" : "ADB shell";
        } catch (Throwable t) {
            return "shell";
        }
    }

    void requestShizukuPermission() {
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("In Shizuku, open Authorized apps and allow XLook");
                openShizuku();
            } else {
                Shizuku.requestPermission(REQUEST_SHIZUKU);
            }
        } catch (Throwable t) {
            toast("Could not ask Shizuku: " + t.getMessage());
        }
    }

    private void tryBind() {
        try {
            if (binding || shell.ready()) return;
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) return;
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return;
            binding = true;
            Shizuku.bindUserService(serviceArgs, connection);
        } catch (Throwable t) {
            binding = false;
        }
    }

    private void notifyState() {
        if (stack.isEmpty()) return;
        top().onShellState();
    }
}
