package app.xlook;

import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;

/** A card of on/off switches. Each switch is one Android setting. State is read from the phone when the card opens. */
final class TweakList {

    static final class Tweak {
        final String title;
        final String sub;
        final String ns;
        final String key;
        final String on;
        final String off;
        final boolean deleteWhenOff;

        Tweak(String title, String sub, String ns, String key, String on, String off, boolean deleteWhenOff) {
            this.title = title;
            this.sub = sub;
            this.ns = ns;
            this.key = key;
            this.on = on;
            this.off = off;
            this.deleteWhenOff = deleteWhenOff;
        }
    }

    private TweakList() {}

    static LinearLayout build(MainActivity a, Tweak[] tweaks) {
        Ui ui = a.ui;
        LinearLayout card = ui.card();
        Switch[] switches = new Switch[tweaks.length];
        String[][] pairs = new String[tweaks.length][];

        for (int i = 0; i < tweaks.length; i++) {
            Tweak t = tweaks[i];
            Switch s = ui.toggle();
            s.setEnabled(false);
            switches[i] = s;
            pairs[i] = new String[] {t.ns, t.key};
            card.addView(ui.row(t.title, t.sub, s));
            if (i < tweaks.length - 1) card.addView(ui.divider());
        }

        a.shell.getSettings(pairs, values -> {
            for (int i = 0; i < tweaks.length; i++) {
                final Tweak t = tweaks[i];
                final Switch s = switches[i];
                s.setChecked(Parse.isOn(values[i]));
                s.setEnabled(true);

                final CompoundButton.OnCheckedChangeListener[] self = new CompoundButton.OnCheckedChangeListener[1];
                self[0] = (button, checked) -> {
                    String cmd;
                    if (checked) {
                        cmd = "settings put " + t.ns + " " + t.key + " " + t.on;
                    } else if (t.deleteWhenOff) {
                        cmd = "settings delete " + t.ns + " " + t.key;
                    } else {
                        cmd = "settings put " + t.ns + " " + t.key + " " + t.off;
                    }
                    a.shell.run(cmd, r -> {
                        if (!r.ok()) {
                            a.toast("Failed: " + r.firstLine());
                            button.setOnCheckedChangeListener(null);
                            button.setChecked(!checked);
                            button.setOnCheckedChangeListener(self[0]);
                        }
                    });
                };
                s.setOnCheckedChangeListener(self[0]);
            }
        });
        return card;
    }
}
