package app.xlook;

import android.view.View;

/** One screen of the app. MainActivity keeps a stack of these. */
abstract class Page {
    final MainActivity a;

    Page(MainActivity a) {
        this.a = a;
    }

    Ui ui() {
        return a.ui;
    }

    Shell sh() {
        return a.shell;
    }

    abstract String title();

    /** Builds the whole screen. Called again whenever the theme, text size or screen density changes. */
    abstract View build();

    /** Called when Shizuku connects or disconnects while this page is on screen. */
    void onShellState() {}

    /** Called when this page leaves the screen. */
    void onLeave() {}
}
