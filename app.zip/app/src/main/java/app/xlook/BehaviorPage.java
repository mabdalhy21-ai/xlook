package app.xlook;

import android.view.View;
import android.widget.LinearLayout;

/** Animation speed, navigation style, screen timeout and developer switches. */
final class BehaviorPage extends Page {
    private static final String NAV_PREFIX = "cmd overlay enable-exclusive --category com.android.internal.systemui.navbar.";

    BehaviorPage(MainActivity a) {
        super(a);
    }

    @Override
    String title() {
        return "Behavior";
    }

    @Override
    View build() {
        Ui ui = ui();
        LinearLayout root = ui.vbox();

        root.addView(ui.section("Speed"));
        root.addView(animationCard(ui));

        root.addView(ui.section("Screen"));
        root.addView(timeoutCard(ui));

        root.addView(ui.section("Navigation"));
        root.addView(navigationCard(ui));

        root.addView(ui.section("Developer"));
        root.addView(TweakList.build(a, new TweakList.Tweak[] {
                new TweakList.Tweak("Show touches", "Draw a dot where your finger is",
                        "system", "show_touches", "1", "0", false),
                new TweakList.Tweak("Pointer location", "Overlay with touch coordinates",
                        "system", "pointer_location", "1", "0", false),
                new TweakList.Tweak("Stay awake while charging", "Screen stays on when plugged in",
                        "global", "stay_on_while_plugged_in", "3", "0", false),
                new TweakList.Tweak("Don't keep activities", "Close each screen as soon as you leave it",
                        "global", "always_finish_activities", "1", "0", false),
        }));
        return ui.scroll(root);
    }

    private View animationCard(Ui ui) {
        LinearLayout c = ui.card();
        c.addView(ui.body("Animation speed"));
        c.addView(ui.hint("Off feels the fastest. Higher numbers slow animations down."));
        final float[] scales = {0f, 0.5f, 1f, 1.5f, 2f};
        Ui.Segmented seg = ui.segmented(new String[] {"Off", "0.5×", "1×", "1.5×", "2×"}, i -> {
            String v = scales[i] == 0f ? "0" : String.valueOf(scales[i]);
            sh().runAll(new String[] {
                    "settings put global window_animation_scale " + v,
                    "settings put global transition_animation_scale " + v,
                    "settings put global animator_duration_scale " + v,
            }, r -> {
                if (!r.ok()) a.toast("Failed: " + r.firstLine());
            });
        });
        LinearLayout.LayoutParams p = Ui.lp(Ui.MATCH, Ui.WRAP);
        p.topMargin = ui.dp(8);
        c.addView(seg, p);
        sh().getSettings(new String[][] {{"global", "animator_duration_scale"}}, values -> {
            float cur = Parse.toFloat(values[0], 1f);
            int best = 0;
            for (int i = 1; i < scales.length; i++) {
                if (Math.abs(scales[i] - cur) < Math.abs(scales[best] - cur)) best = i;
            }
            seg.select(best);
        });
        return c;
    }

    private View timeoutCard(Ui ui) {
        LinearLayout c = ui.card();
        c.addView(ui.body("Screen timeout"));
        final long[] ms = {15000, 30000, 60000, 120000, 300000, 600000};
        Ui.Segmented seg = ui.segmented(new String[] {"15s", "30s", "1m", "2m", "5m", "10m"}, i ->
                sh().run("settings put system screen_off_timeout " + ms[i], r -> {
                    if (!r.ok()) a.toast("Failed: " + r.firstLine());
                }));
        LinearLayout.LayoutParams p = Ui.lp(Ui.MATCH, Ui.WRAP);
        p.topMargin = ui.dp(8);
        c.addView(seg, p);
        sh().getSettings(new String[][] {{"system", "screen_off_timeout"}}, values -> {
            long cur = (long) Parse.toFloat(values[0], -1f);
            for (int i = 0; i < ms.length; i++) {
                if (ms[i] == cur) seg.select(i);
            }
        });
        return c;
    }

    private View navigationCard(Ui ui) {
        LinearLayout c = ui.card();
        c.addView(ui.body("Navigation style"));
        c.addView(ui.hint("Experimental. If it does not stick on your Infinix, change it in Settings > System > Navigation."));
        final int[] current = {-1};
        final Ui.Segmented[] holder = new Ui.Segmented[1];
        holder[0] = ui.segmented(new String[] {"3 buttons", "Gestures"}, i -> {
            final int previous = current[0];
            String cmd = NAV_PREFIX + (i == 0 ? "threebutton" : "gestural");
            sh().run(cmd, r -> {
                if (r.ok()) {
                    current[0] = i;
                } else {
                    a.toast("Failed: " + r.firstLine());
                    holder[0].select(previous);
                }
            });
        });
        LinearLayout.LayoutParams p = Ui.lp(Ui.MATCH, Ui.WRAP);
        p.topMargin = ui.dp(8);
        c.addView(holder[0], p);
        sh().getSettings(new String[][] {{"secure", "navigation_mode"}}, values -> {
            if ("0".equals(values[0])) current[0] = 0;
            else if ("2".equals(values[0])) current[0] = 1;
            holder[0].select(current[0]);
        });
        return c;
    }
}
