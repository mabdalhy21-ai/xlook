package app.xlook;

import android.graphics.Typeface;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Run one shell command as the shell user. Same power as "adb shell". */
final class TerminalPage extends Page {
    private static String lastCommand = "";
    private static String lastOutput = "";

    TerminalPage(MainActivity a) {
        super(a);
    }

    @Override
    String title() {
        return "Terminal";
    }

    @Override
    View build() {
        Ui ui = ui();
        LinearLayout root = ui.vbox();
        root.addView(ui.hint("Runs as the shell user through Shizuku, like adb shell. There is no undo, so be careful."));
        root.addView(ui.gap(10));

        EditText input = ui.input("e.g. getprop ro.product.model");
        input.setTypeface(Typeface.MONOSPACE);
        input.setText(lastCommand);
        input.setImeOptions(EditorInfo.IME_ACTION_GO);
        root.addView(input, Ui.lp(Ui.MATCH, Ui.WRAP));

        LinearLayout card = ui.card();
        TextView out = ui.label(lastOutput, 13, ui.text, false);
        out.setTypeface(Typeface.MONOSPACE);
        out.setTextIsSelectable(true);
        card.addView(out);

        Runnable run = () -> {
            final String cmd = input.getText().toString().trim();
            if (cmd.isEmpty()) return;
            lastCommand = cmd;
            out.setText("Running…");
            sh().run(cmd, r -> {
                String text = "$ " + cmd + "\n" + r.out.trim();
                if (r.code != 0) text += "\n[exit " + r.code + "]";
                lastOutput = text;
                out.setText(text);
            });
        };
        input.setOnEditorActionListener((v, actionId, event) -> {
            run.run();
            return true;
        });

        LinearLayout.LayoutParams bp = Ui.lp(Ui.MATCH, Ui.WRAP);
        bp.topMargin = ui.dp(10);
        bp.bottomMargin = ui.dp(12);
        root.addView(ui.button("Run", true, v -> run.run()), bp);
        root.addView(card);
        return ui.scroll(root);
    }
}
