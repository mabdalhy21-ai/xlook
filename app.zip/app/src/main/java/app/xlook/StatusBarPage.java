package app.xlook;

import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;

import java.util.LinkedHashSet;

/** Status bar tweaks: battery percentage, clock seconds, and hiding icons. */
final class StatusBarPage extends Page {

    /** {label, slot name used by the status bar}. */
    private static final String[][] SLOTS = {
            {"Alarm clock", "alarm_clock"},
            {"Bluetooth", "bluetooth"},
            {"Cast", "cast"},
            {"Data saver", "data_saver"},
            {"Do Not Disturb", "zen"},
            {"Headset", "headset"},
            {"Hotspot", "hotspot"},
            {"Rotation lock", "rotate"},
            {"Volume / ringer", "volume"},
            {"VPN", "vpn"},
            {"Wi-Fi", "wifi"},
            {"Mobile signal", "mobile"},
    };

    private final LinkedHashSet<String> hidden = new LinkedHashSet<>();

    StatusBarPage(MainActivity a) {
        super(a);
    }

    @Override
    String title() {
        return "Status bar";
    }

    @Override
    View build() {
        Ui ui = ui();
        LinearLayout root = ui.vbox();

        root.addView(ui.section("Show"));
        root.addView(TweakList.build(a, new TweakList.Tweak[] {
                new TweakList.Tweak("Battery percentage", "Show the number next to the battery icon",
                        "system", "status_bar_show_battery_percent", "1", "0", false),
                new TweakList.Tweak("Clock with seconds", null,
                        "secure", "clock_seconds", "1", "0", false),
        }));

        root.addView(ui.section("Hide icons"));
        LinearLayout card = ui.card();
        card.addView(ui.hint("Switch on to hide an icon. This replaces the phone's own hidden-icon list; "
                + "Reset all on the home screen puts it back. Some Infinix versions ignore this setting."));

        Switch[] switches = new Switch[SLOTS.length];
        for (int i = 0; i < SLOTS.length; i++) {
            Switch s = ui.toggle();
            s.setEnabled(false);
            switches[i] = s;
            card.addView(ui.row(SLOTS[i][0], null, s));
            if (i < SLOTS.length - 1) card.addView(ui.divider());
        }
        root.addView(card);

        sh().getSettings(new String[][] {{"secure", "icon_blacklist"}}, values -> {
            hidden.clear();
            hidden.addAll(Parse.csv(values[0]));
            for (int i = 0; i < SLOTS.length; i++) {
                final String slot = SLOTS[i][1];
                final Switch s = switches[i];
                s.setChecked(hidden.contains(slot));
                s.setEnabled(true);

                final CompoundButton.OnCheckedChangeListener[] self = new CompoundButton.OnCheckedChangeListener[1];
                self[0] = (button, checked) -> {
                    LinkedHashSet<String> next = new LinkedHashSet<>(hidden);
                    if (checked) next.add(slot);
                    else next.remove(slot);
                    String cmd = next.isEmpty()
                            ? "settings delete secure icon_blacklist"
                            : "settings put secure icon_blacklist " + Parse.joinCsv(next);
                    sh().run(cmd, r -> {
                        if (r.ok()) {
                            hidden.clear();
                            hidden.addAll(next);
                        } else {
                            a.toast("Failed: " + r.firstLine());
                            button.setOnCheckedChangeListener(null);
                            button.setChecked(!checked);
                            button.setOnCheckedChangeListener(self[0]);
                        }
                    });
                };
                s.setOnCheckedChangeListener(self[0]);
            }
        });
        return ui.scroll(root);
    }
}
