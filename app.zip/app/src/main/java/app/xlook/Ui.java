package app.xlook;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** Tiny view toolkit. The whole app is built in code, so there are no layout files to get wrong. */
final class Ui {
    interface IntListener {
        void on(int index);
    }

    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    final Context ctx;
    final float scale;
    final boolean dark;
    final int bg, card, text, sub, accent, onAccent, chip, danger, ok;

    Ui(Context c) {
        ctx = c;
        scale = c.getResources().getDisplayMetrics().density;
        dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bg = dark ? 0xFF0E1013 : 0xFFF3F4F7;
        card = dark ? 0xFF1A1D22 : 0xFFFFFFFF;
        text = dark ? 0xFFEDEEF1 : 0xFF14161A;
        sub = dark ? 0xFF9BA1AB : 0xFF646A74;
        accent = dark ? 0xFF8C9EFF : 0xFF3D5AFE;
        onAccent = dark ? 0xFF0E1013 : 0xFFFFFFFF;
        chip = dark ? 0xFF272B33 : 0xFFE9EBF0;
        danger = dark ? 0xFFFF8A80 : 0xFFD32F2F;
        ok = dark ? 0xFF69DB9A : 0xFF1B8E4B;
    }

    int dp(float v) {
        return Math.round(v * scale);
    }

    GradientDrawable shape(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    Drawable ripple(int color, float radiusDp) {
        int rippleColor = dark ? 0x33FFFFFF : 0x22000000;
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), shape(color, radiusDp), shape(0xFFFFFFFF, radiusDp));
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams weight(float w) {
        return new LinearLayout.LayoutParams(0, WRAP, w);
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    TextView label(CharSequence t, float sp, int color, boolean bold) {
        TextView v = new TextView(ctx);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    TextView body(CharSequence t) {
        return label(t, 16, text, false);
    }

    TextView hint(CharSequence t) {
        TextView v = label(t, 13, sub, false);
        v.setLineSpacing(0, 1.1f);
        return v;
    }

    TextView section(CharSequence t) {
        TextView v = label(t, 12, accent, true);
        v.setAllCaps(true);
        v.setLetterSpacing(0.08f);
        v.setPadding(dp(4), dp(10), 0, dp(8));
        return v;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(shape(card, 20));
        c.setPadding(dp(16), dp(12), dp(16), dp(12));
        LinearLayout.LayoutParams p = lp(MATCH, WRAP);
        p.bottomMargin = dp(12);
        c.setLayoutParams(p);
        return c;
    }

    View gap(int heightDp) {
        View v = new View(ctx);
        v.setLayoutParams(lp(MATCH, dp(heightDp)));
        return v;
    }

    View divider() {
        View v = new View(ctx);
        v.setBackgroundColor(dark ? 0x22FFFFFF : 0x14000000);
        v.setLayoutParams(lp(MATCH, 1));
        return v;
    }

    TextView button(CharSequence t, boolean primary, View.OnClickListener l) {
        TextView b = label(t, 15, primary ? onAccent : accent, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(18), dp(11), dp(18), dp(11));
        b.setBackground(ripple(primary ? accent : chip, 14));
        b.setClickable(true);
        b.setOnClickListener(l);
        return b;
    }

    /** A title with a smaller line under it, and an optional view (like a switch) on the right. */
    LinearLayout row(CharSequence title, CharSequence subtitle, View trailing) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(10), 0, dp(10));
        LinearLayout t = vbox();
        t.addView(body(title));
        if (subtitle != null && subtitle.length() > 0) t.addView(hint(subtitle));
        r.addView(t, weight(1));
        if (trailing != null) {
            LinearLayout.LayoutParams p = lp(WRAP, WRAP);
            p.leftMargin = dp(12);
            r.addView(trailing, p);
        }
        return r;
    }

    Switch toggle() {
        return new Switch(ctx);
    }

    View dot(int color, int sizeDp) {
        View v = new View(ctx);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        v.setBackground(g);
        LinearLayout.LayoutParams p = lp(dp(sizeDp), dp(sizeDp));
        v.setLayoutParams(p);
        return v;
    }

    EditText input(String hintText) {
        EditText e = new EditText(ctx);
        e.setHint(hintText);
        e.setTextColor(text);
        e.setHintTextColor(sub);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setBackground(shape(chip, 14));
        e.setPadding(dp(14), dp(11), dp(14), dp(11));
        return e;
    }

    /** Wraps a page in a scroll view with side padding. */
    ScrollView scroll(View content) {
        ScrollView s = new ScrollView(ctx);
        s.setFillViewport(true);
        s.setClipToPadding(false);
        s.setPadding(dp(16), dp(4), dp(16), dp(28));
        s.addView(content, new ViewGroup.LayoutParams(MATCH, WRAP));
        return s;
    }

    /** A row of options where exactly one can be selected. */
    static final class Segmented extends LinearLayout {
        private final Ui ui;
        private final TextView[] items;

        Segmented(Ui ui, String[] labels, IntListener listener) {
            super(ui.ctx);
            this.ui = ui;
            setOrientation(HORIZONTAL);
            setBackground(ui.shape(ui.chip, 14));
            setPadding(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3));
            items = new TextView[labels.length];
            for (int i = 0; i < labels.length; i++) {
                final int index = i;
                TextView t = ui.label(labels[i], 13, ui.text, true);
                t.setGravity(Gravity.CENTER);
                t.setPadding(ui.dp(4), ui.dp(9), ui.dp(4), ui.dp(9));
                t.setClickable(true);
                t.setOnClickListener(v -> {
                    select(index);
                    listener.on(index);
                });
                items[i] = t;
                addView(t, Ui.weight(1));
            }
            select(-1);
        }

        void select(int selected) {
            for (int i = 0; i < items.length; i++) {
                boolean on = i == selected;
                items[i].setBackground(on ? ui.shape(ui.accent, 11) : null);
                items[i].setTextColor(on ? ui.onAccent : ui.text);
            }
        }
    }

    Segmented segmented(String[] labels, IntListener listener) {
        return new Segmented(this, labels, listener);
    }
}
