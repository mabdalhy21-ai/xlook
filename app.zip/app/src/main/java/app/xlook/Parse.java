package app.xlook;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Locale;

/** Small pure helpers for reading shell output. No Android classes, so they are easy to test. */
final class Parse {
    private Parse() {}

    /** Output of {@code wm density} to {physical, override}. Missing values are -1. */
    static int[] density(String out) {
        int physical = -1;
        int override = -1;
        if (out != null) {
            for (String line : out.split("\n")) {
                String l = line.trim().toLowerCase(Locale.ROOT);
                if (l.startsWith("physical density:")) {
                    physical = intAfterColon(l);
                } else if (l.startsWith("override density:")) {
                    override = intAfterColon(l);
                }
            }
        }
        return new int[] {physical, override};
    }

    private static int intAfterColon(String line) {
        try {
            return Integer.parseInt(line.substring(line.indexOf(':') + 1).trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** One line of {@code settings get}. Returns null when the setting is not set. */
    static String settingValue(String line) {
        if (line == null) return null;
        String t = line.trim();
        if (t.isEmpty() || t.equals("null")) return null;
        return t;
    }

    /** True for any value that is set and is not 0 or false. */
    static boolean isOn(String value) {
        return value != null && !value.equals("0") && !value.equalsIgnoreCase("false");
    }

    static float toFloat(String s, float fallback) {
        if (s == null) return fallback;
        try {
            return Float.parseFloat(s.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    /** Splits output into exactly n lines. Missing lines become empty strings. */
    static String[] lines(String out, int n) {
        String[] result = new String[n];
        String[] parts = out == null ? new String[0] : out.split("\n", -1);
        for (int i = 0; i < n; i++) {
            result[i] = i < parts.length ? parts[i].trim() : "";
        }
        return result;
    }

    static LinkedHashSet<String> csv(String value) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        if (value == null) return set;
        for (String part : value.split(",")) {
            String p = part.trim();
            if (!p.isEmpty()) set.add(p);
        }
        return set;
    }

    static String joinCsv(Collection<String> items) {
        StringBuilder sb = new StringBuilder();
        for (String s : items) {
            if (sb.length() > 0) sb.append(',');
            sb.append(s);
        }
        return sb.toString();
    }

    /** Output of {@code cmd uimode night}, like "Night mode: auto". Returns auto, yes, no or null. */
    static String nightMode(String out) {
        if (out == null) return null;
        String l = out.trim().toLowerCase(Locale.ROOT);
        int i = l.lastIndexOf(':');
        if (i >= 0) l = l.substring(i + 1).trim();
        return (l.equals("auto") || l.equals("yes") || l.equals("no")) ? l : null;
    }

    /** Package names only contain letters, digits, dots and underscores. Used before building shell commands. */
    static boolean safePackage(String p) {
        return p != null && !p.isEmpty() && p.matches("[A-Za-z0-9._]+");
    }

    /** True when a pm / cmd command printed a success line and no failure words. */
    static boolean looksOk(int exitCode, String out) {
        if (exitCode != 0) return false;
        String l = out == null ? "" : out.toLowerCase(Locale.ROOT);
        return !(l.contains("failure") || l.contains("exception") || l.contains("error:") || l.contains("unknown command"));
    }
}
