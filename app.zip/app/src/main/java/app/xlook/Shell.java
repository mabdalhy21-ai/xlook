package app.xlook;

import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** App-side handle for the shell service that Shizuku starts for us. */
final class Shell {

    static final class Result {
        final int code;
        final String out;

        Result(int code, String out) {
            this.code = code;
            this.out = out == null ? "" : out;
        }

        boolean ok() {
            return Parse.looksOk(code, out);
        }

        String firstLine() {
            String t = out.trim();
            int nl = t.indexOf('\n');
            String line = nl >= 0 ? t.substring(0, nl) : t;
            return line.isEmpty() ? "exit code " + code : line;
        }
    }

    interface Callback {
        void done(Result result);
    }

    interface ValuesCallback {
        void done(String[] values);
    }

    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile IBinder binder;

    void setBinder(IBinder b) {
        binder = b;
    }

    boolean ready() {
        IBinder b = binder;
        return b != null && b.pingBinder();
    }

    /** Runs a command on a background thread and calls back on the main thread. */
    void run(String command, Callback callback) {
        pool.execute(() -> {
            Result r = runSync(command);
            if (callback != null) main.post(() -> callback.done(r));
        });
    }

    /** Runs several commands one after another in a single shell call. */
    void runAll(String[] commands, Callback callback) {
        StringBuilder sb = new StringBuilder();
        for (String c : commands) sb.append(c).append('\n');
        run(sb.toString(), callback);
    }

    /** Reads settings. Each pair is {namespace, key}. The callback gets one value per pair, null if unset. */
    void getSettings(String[][] pairs, ValuesCallback callback) {
        StringBuilder sb = new StringBuilder();
        for (String[] p : pairs) {
            sb.append("settings get ").append(p[0]).append(' ').append(p[1]).append('\n');
        }
        run(sb.toString(), r -> {
            String[] lines = Parse.lines(r.out, pairs.length);
            String[] values = new String[pairs.length];
            for (int i = 0; i < values.length; i++) values[i] = Parse.settingValue(lines[i]);
            callback.done(values);
        });
    }

    /** Blocking. Call only from a background thread. */
    Result runSync(String command) {
        IBinder b = binder;
        if (b == null || !b.pingBinder()) {
            return new Result(-1, "Shizuku is not connected");
        }
        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(ShellService.DESCRIPTOR);
            data.writeString(command);
            b.transact(ShellService.TX_EXEC, data, reply, 0);
            reply.readException();
            int code = reply.readInt();
            String out = reply.readString();
            return new Result(code, out);
        } catch (RemoteException | RuntimeException e) {
            return new Result(-1, e.toString());
        } finally {
            data.recycle();
            reply.recycle();
        }
    }
}
