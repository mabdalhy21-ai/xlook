package app.xlook;

import android.content.Intent;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** One-tap links to system settings screens. These do not need Shizuku. */
final class ShortcutsPage extends Page {

    private static final String[][] ITEMS = {
            {"Developer options", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS},
            {"Display", Settings.ACTION_DISPLAY_SETTINGS},
            {"Default apps", Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS},
            {"Default launcher", Settings.ACTION_HOME_SETTINGS},
            {"All apps", Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS},
            {"Battery optimization", Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS},
            {"Battery saver", Settings.ACTION_BATTERY_SAVER_SETTINGS},
            {"Notification access", Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS},
            {"Accessibility", Settings.ACTION_ACCESSIBILITY_SETTINGS},
            {"Usage access", Settings.ACTION_USAGE_ACCESS_SETTINGS},
            {"Display over other apps", Settings.ACTION_MANAGE_OVERLAY_PERMISSION},
            {"Keyboard", Settings.ACTION_INPUT_METHOD_SETTINGS},
            {"Language", Settings.ACTION_LOCALE_SETTINGS},
            {"Date and time", Settings.ACTION_DATE_SETTINGS},
            {"Sound", Settings.ACTION_SOUND_SETTINGS},
            {"Storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS},
            {"Wi-Fi", Settings.ACTION_WIFI_SETTINGS},
            {"Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS},
    };

    ShortcutsPage(MainActivity a) {
        super(a);
    }

    @Override
    String title() {
        return "Shortcuts";
    }

    @Override
    View build() {
        Ui ui = ui();
        LinearLayout root = ui.vbox();
        root.addView(ui.hint("Quick links to system screens that are hard to find in Settings."));
        root.addView(ui.gap(10));

        LinearLayout card = ui.card();
        for (int i = 0; i < ITEMS.length; i++) {
            final String action = ITEMS[i][1];
            LinearLayout row = ui.row(ITEMS[i][0], null, ui.label("›", 22, ui.sub, false));
            row.setClickable(true);
            row.setBackground(ui.ripple(0x00000000, 10));
            row.setOnClickListener(v -> open(action));
            card.addView(row);
            if (i < ITEMS.length - 1) card.addView(ui.divider());
        }
        root.addView(card);

        TextView shizuku = ui.button("Open Shizuku", false, v -> a.openShizuku());
        root.addView(shizuku, Ui.lp(Ui.MATCH, Ui.WRAP));
        return ui.scroll(root);
    }

    private void open(String action) {
        try {
            a.startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (RuntimeException e) {
            a.toast("This phone has no screen for that");
        }
    }
}
