package app.xlook;

import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Home screen: Shizuku status and the list of modules. */
final class HomePage extends Page {
    private LinearLayout shizukuBox;
    private final List<View> gated = new ArrayList<>();

    HomePage(MainActivity a) {
        super(a);
    }

    @Override
    String title() {
        return "XLook";
    }

    @Override
    View build() {
        Ui ui = ui();
        gated.clear();
        LinearLayout root = ui.vbox();

        TextView head = ui.label("XLook", 32, ui.text, true);
        head.setPadding(ui.dp(4), ui.dp(16), 0, 0);
        root.addView(head);
        TextView device = ui.hint(Build.MANUFACTURER + " " + Build.MODEL + "  ·  Android " + Build.VERSION.RELEASE);
        device.setPadding(ui.dp(4), 0, 0, ui.dp(16));
        root.addView(device);

        shizukuBox = ui.card();
        root.addView(shizukuBox);
        fillShizuku();

        root.addView(ui.section("Modules"));
        module(root, "D", "Display", "Display size, text size, dark mode, refresh rate", true,
                () -> a.push(new DisplayPage(a)));
        module(root, "S", "Status bar", "Battery percent, clock seconds, hide icons", true,
                () -> a.push(new StatusBarPage(a)));
        module(root, "B", "Behavior", "Animation speed, navigation, screen timeout, developer switches", true,
                () -> a.push(new BehaviorPage(a)));
        module(root, "A", "Apps", "Disable, remove or restore any app", true,
                () -> a.push(new AppsPage(a)));
        module(root, "L", "Shortcuts", "Jump straight to system settings screens", false,
                () -> a.push(new ShortcutsPage(a)));
        module(root, "T", "Terminal", "Run a shell command with Shizuku", true,
                () -> a.push(new TerminalPage(a)));

        root.addView(ui.section("Maintenance"));
        LinearLayout reset = ui.card();
        reset.addView(ui.body("Reset all tweaks"));
        reset.addView(ui.hint("Puts back the settings XLook can change: display size, text size, dark mode, "
                + "refresh rate, hidden icons, animations and developer switches. Disabled apps are not touched."));
        LinearLayout.LayoutParams bp = Ui.lp(Ui.MATCH, Ui.WRAP);
        bp.topMargin = ui.dp(10);
        TextView resetButton = ui.button("Reset all", false, v -> {
            if (!a.shell.ready()) {
                a.toast("Connect Shizuku first");
                return;
            }
            a.confirm("Reset all tweaks?", "This sets everything XLook can change back to normal.", a::resetAll);
        });
        reset.addView(resetButton, bp);
        root.addView(reset);

        applyGate();
        return ui.scroll(root);
    }

    @Override
    void onShellState() {
        if (shizukuBox != null) fillShizuku();
        applyGate();
    }

    private void applyGate() {
        float alpha = a.shell.ready() ? 1f : 0.5f;
        for (View v : gated) v.setAlpha(alpha);
    }

    private void module(LinearLayout root, String glyph, String name, String desc, boolean needsShell, Runnable open) {
        Ui ui = ui();
        LinearLayout row = ui.hbox();
        row.setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(14));
        row.setBackground(ui.ripple(ui.card, 20));
        row.setClickable(true);

        TextView g = ui.label(glyph, 18, ui.onAccent, true);
        g.setGravity(Gravity.CENTER);
        g.setBackground(ui.shape(ui.accent, 14));
        row.addView(g, Ui.lp(ui.dp(44), ui.dp(44)));

        LinearLayout t = ui.vbox();
        t.addView(ui.label(name, 17, ui.text, true));
        t.addView(ui.hint(desc));
        LinearLayout.LayoutParams tp = Ui.weight(1);
        tp.leftMargin = ui.dp(14);
        row.addView(t, tp);

        row.addView(ui.label("›", 26, ui.sub, false));

        row.setOnClickListener(v -> {
            if (needsShell && !a.shell.ready()) {
                a.toast("Connect Shizuku first");
                return;
            }
            open.run();
        });
        if (needsShell) gated.add(row);

        LinearLayout.LayoutParams rp = Ui.lp(Ui.MATCH, Ui.WRAP);
        rp.bottomMargin = ui.dp(10);
        root.addView(row, rp);
    }

    private void fillShizuku() {
        Ui ui = ui();
        shizukuBox.removeAllViews();

        int color = ui.sub;
        String title = "";
        String text = "";
        String buttonLabel = null;
        Runnable buttonAction = null;

        switch (a.shizukuState()) {
            case NOT_INSTALLED:
                color = ui.danger;
                title = "Shizuku is not installed";
                text = "XLook needs Shizuku to change system settings. Install it, then start it with Wireless debugging.";
                buttonLabel = "Get Shizuku";
                buttonAction = () -> a.openUrl("https://shizuku.rikka.app/download/");
                break;
            case NOT_RUNNING:
                color = ui.danger;
                title = "Shizuku is not running";
                text = "Open Shizuku and tap Start (Wireless debugging). You need to do this again after every restart.";
                buttonLabel = "Open Shizuku";
                buttonAction = a::openShizuku;
                break;
            case TOO_OLD:
                color = ui.danger;
                title = "Shizuku is too old";
                text = "Update Shizuku to version 11 or newer.";
                buttonLabel = "Get Shizuku";
                buttonAction = () -> a.openUrl("https://shizuku.rikka.app/download/");
                break;
            case NEEDS_PERMISSION:
                color = 0xFFE0A800;
                title = "Allow XLook in Shizuku";
                text = "Tap Allow, then confirm in the Shizuku window.";
                buttonLabel = "Allow";
                buttonAction = a::requestShizukuPermission;
                break;
            case CONNECTING:
                color = 0xFFE0A800;
                title = "Connecting to Shizuku…";
                text = "This takes a second or two.";
                break;
            case READY:
                color = ui.ok;
                title = "Shizuku connected";
                text = "XLook can change settings as the " + a.shizukuPrivilege() + " user.";
                break;
        }

        LinearLayout top = ui.hbox();
        top.addView(ui.dot(color, 10));
        TextView tv = ui.label(title, 16, ui.text, true);
        tv.setPadding(ui.dp(10), 0, 0, 0);
        top.addView(tv);
        shizukuBox.addView(top);

        TextView hint = ui.hint(text);
        hint.setPadding(0, ui.dp(6), 0, 0);
        shizukuBox.addView(hint);

        if (buttonLabel != null) {
            final Runnable action = buttonAction;
            LinearLayout.LayoutParams bp = Ui.lp(Ui.MATCH, Ui.WRAP);
            bp.topMargin = ui.dp(12);
            shizukuBox.addView(ui.button(buttonLabel, true, v -> action.run()), bp);
        }
    }
}
